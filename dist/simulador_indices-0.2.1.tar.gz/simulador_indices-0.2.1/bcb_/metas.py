METAS = {
    2022: {"IPCA":3.0, "IGP-M":4.0}
    
}